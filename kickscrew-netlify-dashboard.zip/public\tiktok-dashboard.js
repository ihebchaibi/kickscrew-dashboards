(function () {
  const data = window.KC_TIKTOK_COMPETITOR_DATA;
  const palette = {
    "KICKS CREW": ["#111827", "#0f766e"],
    StockX: ["#113c2b", "#20a36b"],
    GOAT: ["#171717", "#737373"],
    "Stadium Goods": ["#243b53", "#d69e2e"],
    Namshi: ["#8a1238", "#f97316"],
    "SHEIN Arabic": ["#111827", "#ec4899"],
    OUNASS: ["#3f2a16", "#b88746"],
    "Level Shoes": ["#0f172a", "#7c3aed"]
  };

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];

  const state = {
    view: "radar",
    query: "",
    side: "",
    brand: "",
    region: "",
    taxonomy: ""
  };

  function fmtMoney(value) {
    return "$" + Math.round(value || 0).toLocaleString("en-US");
  }

  function fmtNumber(value, digits = 0) {
    return Number(value || 0).toLocaleString("en-US", {
      maximumFractionDigits: digits,
      minimumFractionDigits: digits
    });
  }

  function esc(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function filteredCreatives() {
    const q = state.query.toLowerCase();
    return data.creatives.filter((item) => {
      if (state.side && item.side !== state.side) return false;
      if (state.brand && item.brand !== state.brand) return false;
      if (state.region && item.region !== state.region) return false;
      if (state.taxonomy && !item.taxonomy.includes(state.taxonomy)) return false;
      if (!q) return true;
      return [item.brand, item.headline, item.copy, item.hookText, item.region, item.insight, ...item.taxonomy]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
  }

  function brandStats(rows) {
    const byBrand = new Map();
    rows.forEach((item) => {
      const current = byBrand.get(item.brand) || {
        brand: item.brand,
        side: item.side,
        count: 0,
        spend: 0,
        roasSpend: 0,
        cpaSpend: 0,
        hookRate: 0,
        hooks: 0
      };
      current.count += 1;
      current.spend += item.spendUsd;
      current.roasSpend += item.roas * item.spendUsd;
      current.cpaSpend += item.cpaUsd * item.spendUsd;
      current.hookRate += item.hookRate;
      current.hooks += 1;
      byBrand.set(item.brand, current);
    });
    return [...byBrand.values()].map((item) => ({
      ...item,
      avgRoas: item.roasSpend / Math.max(item.spend, 1),
      avgCpa: item.cpaSpend / Math.max(item.spend, 1),
      avgHookRate: item.hookRate / Math.max(item.hooks, 1)
    }));
  }

  function renderStatus() {
    const live = data.latestRefresh;
    const liveText = live
      ? `Live KPI refresh: ${fmtNumber(live.metrics.totalCreatives)} creatives, ${fmtNumber(live.metrics.videoCount)} videos, ${fmtNumber(live.metrics.imageCount)} images, ${fmtMoney(live.metrics.totalSpend)} spend, ${fmtNumber(live.metrics.avgRoas, 1)}x ROAS. Pulled ${esc(live.pulledAt)}.`
      : "Live KPI refresh has not run yet in this package.";
    $("#statusLine").innerHTML = `<strong>${liveText}</strong><span>${esc(data.meta.confidence)}</span>`;
  }

  function renderMetrics(rows) {
    const own = rows.filter((item) => item.side === "own");
    const competitors = rows.filter((item) => item.side === "competitor");
    const spend = rows.reduce((sum, item) => sum + item.spendUsd, 0);
    const avgRoas = rows.reduce((sum, item) => sum + item.roas * item.spendUsd, 0) / Math.max(spend, 1);
    const avgHook = rows.reduce((sum, item) => sum + item.hookRate, 0) / Math.max(rows.length, 1);
    const cards = [
      ["KC rows", own.length, "Own creative sample"],
      ["Competitor rows", competitors.length, "Tracked external ads"],
      ["Est. spend", fmtMoney(spend), "Row-level sample spend"],
      ["Avg ROAS", `${fmtNumber(avgRoas, 1)}x`, "Weighted by spend"],
      ["Avg hook rate", `${fmtNumber(avgHook, 0)}%`, "First 3 seconds"]
    ];
    $("#metricGrid").innerHTML = cards.map(([label, value, note]) => `
      <section class="metric-card">
        <div class="mini-label">${label}</div>
        <div class="metric-value">${value}</div>
        <div class="metric-note">${note}</div>
      </section>
    `).join("");
  }

  function renderCreatives(rows) {
    if (!rows.length) {
      $("#creativeGrid").innerHTML = `<div class="empty-state"><strong>No creatives match these filters.</strong><p>Clear one filter or search more broadly.</p></div>`;
      return;
    }
    $("#creativeGrid").innerHTML = rows.map((item) => {
      const [a, b] = palette[item.brand] || ["#1f2937", "#64748b"];
      return `
        <article class="creative-card" style="--brand-a:${a};--brand-b:${b}">
          <div class="creative-visual">
            <div class="visual-brand">${esc(item.brand)}</div>
            <div class="visual-copy">${esc(item.headline)}</div>
          </div>
          <div class="creative-body">
            <div class="creative-row">
              <span class="pill ${item.side}">${item.side === "own" ? "KICKS CREW" : "Competitor"}</span>
              <span class="pill">${esc(item.format)} · ${esc(item.region)}</span>
            </div>
            <h3>${esc(item.headline)}</h3>
            <p>${esc(item.copy)}</p>
            <p><strong>Hook:</strong> ${esc(item.hookText)}</p>
            <div class="stats-line">
              <div class="stat-box"><span class="mini-label">ROAS</span><strong>${fmtNumber(item.roas, 1)}x</strong></div>
              <div class="stat-box"><span class="mini-label">CPA</span><strong>${fmtMoney(item.cpaUsd)}</strong></div>
              <div class="stat-box"><span class="mini-label">Hook</span><strong>${fmtNumber(item.hookRate)}%</strong></div>
            </div>
            <p>${esc(item.insight)}</p>
            <div class="tags">${item.taxonomy.slice(0, 6).map((tag) => `<span class="tag">${esc(tag)}</span>`).join("")}</div>
          </div>
        </article>
      `;
    }).join("");
  }

  function renderComparison(rows) {
    const stats = brandStats(rows).sort((a, b) => b.avgRoas - a.avgRoas);
    $("#comparisonTable").innerHTML = stats.map((item) => `
      <tr>
        <td><strong>${esc(item.brand)}</strong><span class="pill ${item.side}">${item.side === "own" ? "Own" : "Competitor"}</span></td>
        <td>${item.count}</td>
        <td>${fmtMoney(item.spend)}</td>
        <td>${fmtNumber(item.avgRoas, 1)}x</td>
        <td>${fmtMoney(item.avgCpa)}</td>
        <td>${fmtNumber(item.avgHookRate)}%</td>
      </tr>
    `).join("");

    const max = Math.max(...stats.map((item) => item.avgRoas), 1);
    $("#comparisonBars").innerHTML = stats.map((item) => `
      <div class="bar-row">
        <strong>${esc(item.brand)}</strong>
        <div class="bar-track"><div class="bar-fill" style="width:${Math.max((item.avgRoas / max) * 100, 4)}%"></div></div>
        <span>${fmtNumber(item.avgRoas, 1)}x</span>
      </div>
    `).join("");
  }

  function renderHooks(rows) {
    const videoRows = rows.filter((item) => item.format === "video").sort((a, b) => b.hookRate - a.hookRate);
    $("#hookTable").innerHTML = videoRows.map((item) => `
      <tr>
        <td><strong>${esc(item.brand)}</strong>${esc(item.region)}</td>
        <td>${esc(item.hookText)}</td>
        <td>${fmtNumber(item.hookRate)}%</td>
        <td>${fmtNumber(item.roas, 1)}x</td>
        <td>${esc(item.taxonomy.find((tag) => data.meta.taxonomy.hookTactic.includes(tag)) || "Unclassified")}</td>
      </tr>
    `).join("");
  }

  function renderHeatmap() {
    $("#heatmap").innerHTML = data.demographicHeatmap.map((item) => `
      <div class="heat-cell" style="--score:${Math.min(item.roas, 14)}">
        <span class="mini-label">${esc(item.region)} · ${esc(item.age)} · ${esc(item.gender)}</span>
        <strong>${fmtNumber(item.roas, 1)}x</strong>
        <span>ROAS</span>
      </div>
    `).join("");
  }

  function renderIntelligence() {
    $("#intelList").innerHTML = data.intelligence.map((item) => `
      <article class="intel-card">
        <span class="priority ${item.priority.toLowerCase()}">${esc(item.priority)}</span>
        <h3>${esc(item.title)}</h3>
        <p><strong>Why:</strong> ${esc(item.why)}</p>
        <p><strong>Action:</strong> ${esc(item.action)}</p>
      </article>
    `).join("");
  }

  function renderBriefs() {
    $("#briefGrid").innerHTML = data.creativeBriefs.map((item) => `
      <article class="brief-card">
        <span class="pill">${esc(item.format)}</span>
        <h3>${esc(item.title)}</h3>
        <p><strong>Audience:</strong> ${esc(item.audience)}</p>
        <p><strong>Hook:</strong> ${esc(item.hook)}</p>
        <ul>${item.scenes.map((scene) => `<li>${esc(scene)}</li>`).join("")}</ul>
        <p>${esc(item.why)}</p>
      </article>
    `).join("");
  }

  function renderRegional(rows) {
    const regions = data.meta.trackedRegions.map((region) => {
      const inRegion = rows.filter((item) => item.region === region);
      const spend = inRegion.reduce((sum, item) => sum + item.spendUsd, 0);
      const roas = inRegion.reduce((sum, item) => sum + item.roas * item.spendUsd, 0) / Math.max(spend, 1);
      return { region, count: inRegion.length, brands: new Set(inRegion.map((item) => item.brand)).size, spend, roas };
    });
    $("#regionalTable").innerHTML = regions.map((item) => `
      <tr>
        <td><strong>${esc(item.region)}</strong></td>
        <td>${item.count}</td>
        <td>${item.brands}</td>
        <td>${fmtMoney(item.spend)}</td>
        <td>${fmtNumber(item.roas, 1)}x</td>
      </tr>
    `).join("");
  }

  function renderTaxonomyOptions() {
    const tags = [...new Set(data.creatives.flatMap((item) => item.taxonomy))].sort();
    $("#taxonomyFilter").innerHTML = `<option value="">All taxonomy tags</option>` + tags.map((tag) => `<option value="${esc(tag)}">${esc(tag)}</option>`).join("");
  }

  function populateFilters() {
    $("#brandFilter").innerHTML = `<option value="">All brands</option>` + data.meta.trackedBrands.map((brand) => `<option value="${esc(brand)}">${esc(brand)}</option>`).join("");
    $("#regionFilter").innerHTML = `<option value="">All regions</option>` + data.meta.trackedRegions.map((region) => `<option value="${esc(region)}">${esc(region)}</option>`).join("");
    renderTaxonomyOptions();
  }

  function render() {
    const rows = filteredCreatives();
    renderStatus();
    renderMetrics(rows);
    renderCreatives(rows);
    renderComparison(rows);
    renderHooks(rows);
    renderRegional(rows);
    renderHeatmap();
    renderIntelligence();
    renderBriefs();
  }

  function bind() {
    $$(".nav-tabs button").forEach((button) => {
      button.addEventListener("click", () => {
        state.view = button.dataset.view;
        $$(".nav-tabs button").forEach((btn) => btn.classList.toggle("active", btn === button));
        $$(".view").forEach((view) => view.classList.toggle("active", view.id === `${state.view}View`));
      });
    });
    $("#searchFilter").addEventListener("input", (event) => {
      state.query = event.target.value;
      render();
    });
    $("#sideFilter").addEventListener("change", (event) => {
      state.side = event.target.value;
      render();
    });
    $("#brandFilter").addEventListener("change", (event) => {
      state.brand = event.target.value;
      render();
    });
    $("#regionFilter").addEventListener("change", (event) => {
      state.region = event.target.value;
      render();
    });
    $("#taxonomyFilter").addEventListener("change", (event) => {
      state.taxonomy = event.target.value;
      render();
    });
    $("#resetFilters").addEventListener("click", () => {
      state.query = "";
      state.side = "";
      state.brand = "";
      state.region = "";
      state.taxonomy = "";
      ["#searchFilter", "#sideFilter", "#brandFilter", "#regionFilter", "#taxonomyFilter"].forEach((selector) => {
        $(selector).value = "";
      });
      render();
    });
  }

  populateFilters();
  bind();
  render();
})();
